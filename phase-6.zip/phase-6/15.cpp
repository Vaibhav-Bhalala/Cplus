/*

15. Calculate toal coast to apply a Solar Powered Panels
for your Home Rooftop. Apply all types of government aid
percentage to find reasonable coast.

*/

#include <iostream>

using namespace std;

int main()
{
    const double panelCost = 50000; // cost of one solar panel
    const double installationCost = 10000; // cost of installation per panel
    double totalPanels; // total number of panels required
    double totalCost; // total cost of installation
    double governmentAid = 0.3; // percentage of government aid


    cout << "Enter the total number of solar panels required: ";
    cin >> totalPanels;


    totalCost = (panelCost * totalPanels) + (installationCost * totalPanels);
    

    totalCost -= totalCost * governmentAid;


    cout << "Total cost of installing solar panels after government aid: " << totalCost << " INR" << endl;


}


