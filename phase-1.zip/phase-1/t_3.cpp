/*3.student in fifth class encounters very easy math problem to find quotient and remainder.
write a c++ program which provides a solution for this particular problem.*/
#include <iostream>
using namespace std;

int main() {
  int x,y,quotient,remainder;

  cout << "Enter the value of X : ";
  cin >> x;

  cout << "Enter the value of Y : ";
  cin >> y;

  quotient = x/y;
  remainder = x%y;

  cout << "Quotient = " << quotient << endl;
  cout << "Remainder = " << remainder << endl;

}

