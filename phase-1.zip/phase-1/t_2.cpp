/*sameer is too weak to find multiplication of any three numbers.write a c++ program which helps
sameer to solve his issue. */
#include <iostream>
using namespace std;

main() {
 
   int n1,n2,n3,multi;
  
   cout << "Enter three numbers: ";
   cin >> n1 >> n2 >> n3;
  
   multi = n1*n2*n3;
  
   cout << "The multiplication of " << n1 << ", " << n2 << ", and " << n3 << " is " << multi << endl;
   
}

