/*4.two classmate wants to exchange their seating with each other.but the problem is
there are only two chairs in small classroom which are aquire by them.write a c++ program which 
provides solution for this particular problem. */
#include <iostream>
using namespace std;

int main() {
  int c1 = 1; 
  int c2 = 1;

  cout << "Initial seating arrangement:\n";
  cout << "Chair 1: " << (c1 == 1 ? "occupied" : "unoccupied") << endl;
  cout << "Chair 2: " << (c2 == 1 ? "occupied" : "unoccupied") << endl;

  
  int temp = c1;
  c1 = c2;
  c2 = temp;

  cout << "Final seating arrangement:\n";
  cout << "Chair 1: " << (c1 == 1 ? "occupied" : "unoccupied") << endl;
  cout << "Chair 2: " << (c2 == 1 ? "occupied" : "unoccupied") << endl;

}

