/*1.meena face an issue to perform mathemical operation to find a cube of any number.write c++
program which helps meena to solve her issue */
#include <iostream>
using namespace std;

int main() {
    int n, cube;
    
    cout << "Enter a number: ";
    cin >> n;
    
    
    cube = n*n*n;
    
    cout << "The cube of " << n << " is " << cube << endl;
    
}

