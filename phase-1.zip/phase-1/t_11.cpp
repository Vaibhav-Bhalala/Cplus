/*11.raman have an idea to impress his computer teacher by solving square root of number
without using any programming library.write a c++ program to help raman. 
*/
#include <iostream>
using namespace std;

int main() {

  int number, guess, last_guess = 0;
  const float epsilon = 0.00001;

  cout << "Enter a positive number: ";
  cin >> number;
  
  guess = number / 2.0;
  while (abs(guess - last_guess) > epsilon) 
  {
    last_guess = guess;
    guess = (guess + number / guess) / 2.0;
  }


  cout << "The square root of " << number << " is " << guess << endl;

}

