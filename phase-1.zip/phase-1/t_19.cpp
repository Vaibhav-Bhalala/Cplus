/*19.write a c++ program to print table of any number less than 10.a group of needy nubie math
students will appriciate your help.
*/
#include <iostream>
using namespace std;

int main() {
    int n, i;

    cout << "Enter the number : ";
    cin >> n;

    for(i=1;i<=10;i++) 
	{
        cout << n << " x " << i << " = " << n*i << endl;
    }

}

