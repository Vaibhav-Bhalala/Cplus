/*8.a sport coach needs to convert submitted parcipant's inches into feet and inches for height 
measurement.write a c++ program to provide solution for this.*/
#include <iostream>
using namespace std;

int main() {

  int inches,feet,remaining_inches;

  cout << "Enter height in inches: ";
  cin >> inches;

  feet = inches/12;
  remaining_inches = inches%12;

  cout << "Height is " << feet << " feet " << remaining_inches << " inches" << endl;

}

